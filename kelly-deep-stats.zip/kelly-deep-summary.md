# Kelly Deep Stats Summary

Generated files: kelly-deep-stats.csv, kelly-hashtags.csv, kelly-lengths.csv, kelly-engagement-by-hour.csv

Top 10 words:
- the: 25
- to: 25
- and: 20
- in: 18
- is: 17
- my: 12
- for: 12
- factory: 12
- i: 10
- of: 9

Top 10 hashtags:

Tweet length bins:
- 0-50: 2
- 51-100: 2
- 101-150: 4
- 151-280: 20

Engagement by hour (Central Time):
- 00:00 CT — avg likes: 0.00, avg retweets: 0.00
- 01:00 CT — avg likes: 0.00, avg retweets: 0.00
- 02:00 CT — avg likes: 0.00, avg retweets: 0.00
- 03:00 CT — avg likes: 0.00, avg retweets: 0.00
- 04:00 CT — avg likes: 0.00, avg retweets: 0.00
- 05:00 CT — avg likes: 0.00, avg retweets: 0.00
- 06:00 CT — avg likes: 0.00, avg retweets: 0.00
- 07:00 CT — avg likes: 0.00, avg retweets: 0.00
- 08:00 CT — avg likes: 0.00, avg retweets: 0.00
- 09:00 CT — avg likes: 0.00, avg retweets: 0.00
- 10:00 CT — avg likes: 0.00, avg retweets: 0.00
- 11:00 CT — avg likes: 0.00, avg retweets: 0.00
- 12:00 CT — avg likes: 0.00, avg retweets: 0.00
- 13:00 CT — avg likes: 0.00, avg retweets: 0.00
- 14:00 CT — avg likes: 0.00, avg retweets: 0.00
- 15:00 CT — avg likes: 0.00, avg retweets: 0.00
- 16:00 CT — avg likes: 0.00, avg retweets: 0.00
- 17:00 CT — avg likes: 0.00, avg retweets: 0.00
- 18:00 CT — avg likes: 0.00, avg retweets: 0.00
- 19:00 CT — avg likes: 0.00, avg retweets: 0.00
- 20:00 CT — avg likes: 0.00, avg retweets: 0.00
- 21:00 CT — avg likes: 0.00, avg retweets: 0.00
- 22:00 CT — avg likes: 0.00, avg retweets: 0.00
- 23:00 CT — avg likes: 0.00, avg retweets: 0.00